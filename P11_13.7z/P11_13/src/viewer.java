import javax.swing.JFrame;


public class viewer {

	public static void main(String[] args) {
		
		
				JFrame rectFrame = new RectangleFrame();
				rectFrame.setSize(320, 440);
				rectFrame.setTitle("The Greatest Thing in the World!");
				rectFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				rectFrame.setVisible(true);

	}

}
